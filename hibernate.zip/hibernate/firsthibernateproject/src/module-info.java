/**
 * 
 */
/**
 * @author LENOVO
 *
 */
interface firsthibernateproject {
}