package com.kiranacademy;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Clientcriteria {

	
	
	public static void main(String[] args) {


		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Employee.class);
		
		
		SessionFactory factory = cfg.buildSessionFactory(); //connection factory
		Session session =factory.openSession();
		
		
		
		Criteria criteria = session.createCriteria(Employee.class);//select * from employee
         
		List<Employee> emplist=criteria.list();
		
		for(Employee employee:emplist) {
			System.out.println(employee);
		}
	}

}
