package com.kiranacademy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Clientsave {

	public static void main(String[] args) {
	
		Configuration cfg=new Configuration();
		
		cfg.configure();//if not given cfg name then hibernate will automatically give hibernate.cfg.xml name(by default)
		
		cfg.addAnnotatedClass(Employee.class); //this is a class maps with database we need to mention mapping class here.
		
		
		SessionFactory factory = cfg.buildSessionFactory(); //connection factory
		Session session =factory.openSession(); //connection
		
		Transaction transaction=session.beginTransaction();
		
		Employee employee=new Employee(5,"achla");
		
		session.save(employee);
		transaction.commit();

	}

}
