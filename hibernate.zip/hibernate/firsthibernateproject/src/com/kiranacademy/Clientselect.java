package com.kiranacademy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Clientselect {

	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Employee.class);
		
		
		SessionFactory factory = cfg.buildSessionFactory(); //connection factory
		Session session =factory.openSession();
		
		Employee employee = session.load(Employee.class,1);  // 1 is primary key we load data by using this.
		System.out.println(employee);
		
		
		
		
	

	}

}
